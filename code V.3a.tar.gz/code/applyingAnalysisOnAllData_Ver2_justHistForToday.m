clear
clc
close all

addpath('NIfTI_20140122')
% 
DirNames = dir('../data/old/');
NumSubfields = 1;

% DirNames = dir('../data/');
% NumSubfields = 11;

DirNames = DirNames(3:end-1);
                   
flag_InitialReadingMode.mode = 'OneOrgan';
flag_InitialReadingMode.OrganIndex = 1;

flag_AnalysisMode = 'OrgansSeperately'; % 'OrgansSimultaneously'; 'OrgansSeperately';
show = 0;

for subjectNum = 1%:length(DirNames)
    fprintf(' \n -----  Subject: %s  -----\n',DirNames(subjectNum).name)

    Initialization

    show = 0;
    NumBins = 30;
    PosThresh = 0.5;
    ah = zeros(3,NumBins,NumSubfields);   ac = ah*0;
    bh = zeros(3,NumBins,NumSubfields);   bc = bh*0;
    Mean = zeros(NumSubfields,3);
    Median = zeros(NumSubfields,3);
    FWHM = nan(NumSubfields,3);
    for modalityNum = 1:length(FinalData)
        subDir = FinalData(modalityNum).address;
%         NumSubfields = length(subDir);
        AllOrgansParallel = [];
        for sfInd = 1:NumSubfields
            
            dataT1subfield = load_nii([subDir(sfInd).folder,'/',subDir(sfInd).name]);
            OrganIm = dataT1subfield.img;
            
            K = OrganIm(OrganIm > PosThresh );
            Mean(sfInd,modalityNum) = mean(K(:));
            Median(sfInd,modalityNum) = median(K(:));
            [ah(modalityNum,:,sfInd),bh(modalityNum,:,sfInd)] = hist(reshape(OrganIm(OrganIm>PosThresh),1,[]),NumBins);
            bc(modalityNum,:,sfInd) = fliplr(bh(modalityNum,:,sfInd));
            ac(modalityNum,:,sfInd) = cumsum(fliplr(ah(modalityNum,:,sfInd)))/sum(ah(modalityNum,:,sfInd));

            try
                FWHM(sfInd,modalityNum) = fwhm(bh(modalityNum,:,sfInd),ah(modalityNum,:,sfInd));
            catch
            end

        end
    end

end
%% showing
if show 
    for sfInd = 1:NumSubfields
        name = FinalData(1).address(sfInd).name(16:end-11);

        string = ['subject:',DirNames(subjectNum).name , '      organ: ',name];
        string = strrep(string,'_','\_');
        figure ,
        subplot(121) , title(string,'fontsize',9)
        ylabel('posteriori histogram')
        hold on
        plot(bh(1,:,sfInd),ah(1,:,sfInd),'.g'), plot(bh(2,:,sfInd),ah(2,:,sfInd),'.blue'), plot(bh(3,:,sfInd),ah(3,:,sfInd),'.r')
        plot(bh(1,:,sfInd),ah(1,:,sfInd),'g') , plot(bh(2,:,sfInd),ah(2,:,sfInd),'blue') , plot(bh(3,:,sfInd),ah(3,:,sfInd),'r')
        legend('T1','T2','wmn')

        subplot(122)
        set ( gca, 'xdir', 'reverse' )
        ylabel('cumulative fliplr of histogram')
        hold on
        plot(bc(1,:,sfInd),ac(1,:,sfInd),'.g'), plot(bc(2,:,sfInd),ac(2,:,sfInd),'.blue'), plot(bc(3,:,sfInd),ac(3,:,sfInd),'.r')
        plot(bc(1,:,sfInd),ac(1,:,sfInd),'g') , plot(bc(2,:,sfInd),ac(2,:,sfInd),'blue') , plot(bc(3,:,sfInd),ac(3,:,sfInd),'r')
        legend('T1','T2','wmn')

        if NumSubfields > 1  && sfInd < NumSubfields
            pause
        end
    end
end
%%
clear name
    for sfInd = 1:NumSubfields
        name{sfInd} = FinalData(1).address(sfInd).name(16:end-11);
    end
    T1_mean  = Mean(:,1);
    T2_mean  = Mean(:,2);
    wmn_mean = Mean(:,3);
    MeanValues = table(T1_mean,T2_mean,wmn_mean,'RowNames',name)
    
    T1_median  = Median(:,1);
    T2_median  = Median(:,2);
    wmn_median = Median(:,3);
    MedianValues = table(T1_median,T2_median,wmn_median,'RowNames',name)

    T1_FWHM  = FWHM(:,1);
    T2_FWHM  = FWHM(:,2);
    wmn_FWHM = FWHM(:,3);
    FWHMValues = table(T1_FWHM,T2_FWHM,wmn_FWHM,'RowNames',name)    
    