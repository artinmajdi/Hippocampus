clear
clc
close all

addpath('NIfTI_20140122')
mainDir = '../../data/';
DirNames = dir(mainDir);
k = [];
for i = 1:length(DirNames)
    if(length(DirNames(i).name) == 13)
        k = [k,i];
    end
end
DirNames = DirNames(k);

%% First Step: finding the segment in each modality

show.figShow = 0;
show.tableShow = 0;

%% writing section

mode = 'read';
switch mode
    case 'write'
        WriteSectionMain
        
    case 'read'
        
        for Mode11 = 1:2
            for RegMode = 1:2
                
                switch Mode11
                    case 1
                        stateMode2 = 'with11';
                    case 2
                        stateMode2 = 'without11';
                end
                
                switch RegMode
                    case 1
                        stateMode = 'afterRegistration';
                        LL = 3;
                    case 2
                        stateMode = 'beforeRegistration';
                        LL = 2;
                end
                for strgInd = 1:LL
                    
                    switch strgInd
                        case 1
                            strg = 'Mean';
                        case 2
                            strg = 'Median';
                        case 3
                            strg = 'AveNumPosMaxChosen';
                    end
                    
                    show.tableShow = 1;
                    ReadSectionMain
                    
                    %% mode to Analyse
                    % a: [subjects , modality , subfields]
                    
                    nameString = [strg,' ', stateMode , ' ', stateMode2];
                    DiaryName = ['*    ',nameString,'.txt'];
                    diary(DiaryName)
                    
                    a = Data.(strg);
                    disp(['          ----------------   ',strg,'   ---------------'])
                    
                    for subfieldInd = 1:L
                        name{subfieldInd} = subDirT1(subfieldInd).name(16:end-11);
                    end
                    name{L+1} = '**WHOLE HIPPOCAMPUS**';
                    
                    %% t-test results
                    ttestPvalueO = t_testing(a,L,name,show);
                    
                    %% Which modality is significant?
                    [SigMap , SigMap2] = Significance(a,ttestPvalueO,name,show);
                    diary off
                    OutputDir = [mainDir,'Outputs/',stateMode2,'/',stateMode,'/',strg,'/',];
                    mkdir(OutputDir)
                    movefile(DiaryName,[OutputDir,DiaryName]);
                    
                    %%  boxploting the results
                    %         a = Mean;
                    % a: [subjects , modality , subfields]
                    close all
                    modeShowResult = 'Subfield';
                    for subfieldInd = 1:L
                        switch modeShowResult
                            case 'Subfield'
                                bpA = a(:,:,subfieldInd);
                                
                            case 'wholeHippocampus'
                                % [subjects , modality , subfields]
                                [y,md,z] = size(a);
                                bpA = zeros(y*z,md);
                                for mdId = 1:md
                                    bpA(:,mdId) = reshape(a(:,mdId,:),[],1);
                                end
                        end
                        nme = strrep(name{subfieldInd},'_','\_');
                        
                        aS = 'T1';
                        bS = 'T2';
                        cS = 'wmn';
                        
                        if strcmp(SigMap{subfieldInd,1} , 'T1')  % T1 - T2
                            if strcmp(SigMap{subfieldInd,2} , 'T1')  % T1 - wmn
                                aS = 'T1*';
                            else
                                if strcmp(SigMap{subfieldInd,3} , 'WMN')  % T2 - wmn
                                    cS = 'wmn*';
                                end
                            end
                        else
                            if strcmp(SigMap{subfieldInd,3} , 'WMN')
                                cS = 'wmn*';
                            elseif strcmp(SigMap{subfieldInd,3} , 'T2')
                                bS = 'T2*';
                            end
                        end
                        
                        boxplot(bpA,{aS,bS,cS}),title(nme)
                        ylabel(strg)
                        
                        %         AxesH = gca;   % Not the GCF
                        %         F = getframe(AxesH);
                        %         imwrite(F.cdata, [mainDir,'Outputs/Mean ' , name{subfieldInd},'.jpg']);
                        
                        saveas(gca, [OutputDir,nameString, ' ', name{subfieldInd},'.jpg'])
                    end
                end
            end
        end
end














